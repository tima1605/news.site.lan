<?php

require_once __DIR__ . '/MysqliDb.php';

$db = new MysqliDb('localhost', 'root', '', 'news_site_db');

session_start();

$name_script = explode('/', $_SERVER['SCRIPT_NAME']);

preg_match_all('/^(.*?).php+$/', $name_script[1], $m);
$name_page = $m[1][0];

$login = 'admin';
$password = 'test';

switch ($name_page) {

    case 'index':
        if(isset($_POST['search']) and !empty($_POST['search'])){
            $news = $db->rawQuery("SELECT * FROM news WHERE title LIKE '%{$_POST['search']}%' OR short_description LIKE '%{$_POST['search']}%'");
        } elseif (isset($_POST['search_date']) and !empty($_POST['search_date'])) {
            $dateSql = date("Y-m-d", strtotime($_POST['search_date']));
            $news = $db->rawQuery("SELECT * FROM news WHERE created_at BETWEEN '{$dateSql} 00:00:00' AND '{$dateSql} 23:59:59'");
        } else {
            $page = 1;
            if (isset($_GET["page"]) and !empty($_GET["page"])) {
                $page = $_GET["page"];
            }
            // set page limit to 3 results per page. 20 by default
            $db->pageLimit = 3;
            $db->orderBy("created_at","Desc");
            $news = $db->arraybuilder()->paginate("news", $page);
        }
        
        break;
    
    case 'news':
        if (isset($_GET["id"]) and !empty($_GET["id"])) {
            $db->where ("id", $_GET["id"]);
            $newsOne = $db->getOne ("news");
        } 
        break;
    
    case 'adminNews':
        if(isset($_SESSION['user']) and !empty($_SESSION['user'])){
            $db->orderBy("created_at","Desc");
            $adminNews = $db->get('news');
        } else {
            if(isset($_POST['login']) and isset($_POST['password'])){
                if($_POST['login'] == $login and $_POST['password'] == $password){
                    $_SESSION['user'] = $login;
                    
                    $db->orderBy("created_at","Desc");
                    $adminNews = $db->get('news');
                }
            }
        }
        break;
    
    case 'createNews':
        if(!isset($_SESSION['user']) or empty($_SESSION['user'])){
            header("Location: /admin");
            die();
        }
        break;
    
    case 'deleteNews':
        if(isset($_SESSION['user']) and !empty($_SESSION['user'])){
            if(isset($_GET['delete_news_id']) and !empty($_GET['delete_news_id'])){
                $db->where('id', $_GET['delete_news_id']);
                if($db->delete('news')) {
                    header("Location: /admin");
                    die();
                }
            }
        } else {
            header("Location: /admin");
            die();
        }
        break;
    
    case 'editNews':
        if(isset($_SESSION['user']) and !empty($_SESSION['user'])){
            if (isset($_GET["edit_news_id"]) and !empty($_GET["edit_news_id"])) {
                $db->where ("id", $_GET["edit_news_id"]);
                $newsEditOne = $db->getOne ("news");
            }
        } else {
            header("Location: /admin");
            die();
        }
        break;
    case 'logout':
        session_destroy(); 
        header("Location: /admin");
        die();
        break;
}

    
       




