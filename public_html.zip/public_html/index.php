<?php
require_once __DIR__ . '/libs/core2.php';

require_once __DIR__ . '/inc/header.php';
?>

<!-- Page Header-->
<header class="masthead" style="background-image: url('assets/img/home-bg.jpg')">
    <div class="container position-relative px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-7">
                <div class="site-heading">
                    <h1>Новини</h1>
                    <span class="subheading">Новини вашого міста</span>
                    <br />
                    <form action="/index" method="post">
                        <input class="form-control" type="text" name="search" placeholder="Введіть текст для пошуку" />
                        <br />
                        <button class="btn btn-primary text-uppercase" type="submit">Send</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- Main Content-->
<div class="container px-4 px-lg-5">
    <div class="row gx-4 gx-lg-5 justify-content-center">
        <div class="col-md-10 col-lg-8 col-xl-7">
            <p>Пошук новин за датою</p>
            <form action="/index" method="post">
                <input class="form-control" type="text" name="search_date" placeholder="Введіть дату у форматі: 01.01.2024" />
                <br />
                <button class="btn btn-primary text-uppercase" type="submit">Send</button>
            </form>
            <?php if(count($news) > 0){ ?>
                <?php foreach($news as $newsOne){ ?>
                    <!-- Post preview-->
                    <div class="post-preview">
                        <a href="/news/<?php echo $newsOne['id'] ?>">
                            <h2 class="post-title"><?php echo $newsOne['title'] ?></h2>
                            <h3 class="post-subtitle"><?php echo $newsOne['short_description'] ?></h3>
                        </a>
                        <p class="post-meta">
                            <?php echo date('d.m.Y H:i:s', strtotime($newsOne['created_at'])) ?>
                        </p>
                        <p class="post-meta">
                            <a href="/news/<?php echo $newsOne['id'] ?>">Детальніше</a>
                        </p>
                    </div>
                    <!-- Divider-->
                    <hr class="my-4" />
                <?php } ?>
            <?php } ?>
            <!-- Pager-->
            <!--<div class="d-flex justify-content-end mb-4"><a class="btn btn-primary text-uppercase" href="#!">Older Posts →</a></div>-->
            <div class="d-flex justify-content-end mb-4">
                <?php
                if((!isset($_POST['search']) or empty($_POST['search'])) and (!isset($_POST['search_date']) or empty($_POST['search_date']))){
                    if($page == 1){
                        $prev = '';
                        $next = '<a class="page_num" href="/index_p'.($page + 1).'">next</a>';
                    } elseif($page == $db->totalPages){
                        $prev = '<a class="page_num" href="/index_p'.($page - 1).'">prev</a>';
                        $next = '';
                    } else {
                        $prev = '<a class="page_num" href="/index_p'.($page - 1).'">prev</a>';
                        $next = '<a class="page_num" href="/index_p'.($page + 1).'">next</a>';
                    }
                    $linePage = $prev. "сторінка ".$page." з " . $db->totalPages . $next;
                    echo $linePage;
                }
                ?>
            </div>
        </div>
    </div>
</div>

<?php
require_once __DIR__ . '/inc/footer.php';
