<?php
require_once __DIR__ . '/libs/core2.php';
require_once __DIR__ . '/inc/header_admin.php';

?>

<!-- Page Header-->
<header class="masthead" style="background-image: url('/assets/img/about-bg.jpg')">
    <div class="container position-relative px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-7">
                <div class="page-heading">
                    <h1>Адміністративна сторінка</h1>
                    <span class="subheading">Новини вашого міста</span>
                </div>
            </div>
        </div>
    </div>
</header>
<?php if(isset($_SESSION['user']) and !empty($_SESSION['user'])){ ?>
<!-- Main Content-->
<div class="container px-4 px-lg-5">
    <div class="row gx-4 gx-lg-5 justify-content-center">
        <div class="col-md-10 col-lg-8 col-xl-7">
            <a class="btn btn-primary text-uppercase" href="/create-news" >Додати новину</a>
            <?php if(count($adminNews) > 0){ ?>
                <?php foreach($adminNews as $adminNewsOne){ ?>
                    <!-- Post preview-->
                    <div class="post-preview">
                        <a href="/news/<?php echo $adminNewsOne['id'] ?>">
                            <h2 class="post-title"><?php echo $adminNewsOne['title'] ?></h2>
                            <h3 class="post-subtitle"><?php echo $adminNewsOne['short_description'] ?></h3>
                        </a>
                        <p class="post-meta">
                            <?php echo date('d.m.Y H:i:s', strtotime($adminNewsOne['created_at'])) ?>
                        </p>
                        <p class="post-meta"><a class="color_link_blue" href="/edit-news/<?php echo $adminNewsOne['id'] ?>">Редагувати</a></p>
                        <p class="post-meta"><a class="color_link_red" href="/delete-news/<?php echo $adminNewsOne['id'] ?>">Видалити</a></p>
                    </div>
                    <!-- Divider-->
                    <hr class="my-4" />
                <?php } ?>
            <?php } ?>
        </div>
    </div>
</div>
<?php } else { ?>
    <div class="container px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-7">
                <form id="contactForm" data-sb-form-api-token="API_TOKEN" action="/admin" method="post">
                    <div class="form-floating">
                        <input class="form-control" type="text" name="login" placeholder="Введіть логін" />
                        <label for="name">Логін<span class="snowflake">*</span></label>
                    </div>

                    <div class="form-floating">
                        <input class="form-control" type="password" name="password" placeholder="Введіть пароль" />
                        <label for="name">Пароль<span class="snowflake">*</span></label>
                    </div>

                    <!-- Submit Button-->
                    <button class="btn btn-primary text-uppercase" id="submitButton" type="submit">Send</button>
                </form>
            </div>
        </div>
    </div>
<?php } ?>

<?php
require_once __DIR__ . '/inc/footer.php';
