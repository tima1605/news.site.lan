<?php
require_once __DIR__ . '/libs/core2.php';
require_once __DIR__ . '/inc/header_admin.php';

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    if (isset($_POST['title']) and mb_strlen($_POST['title']) > 30){
       $errors['title_len'] = "В полі Заголовок не може бути більше 30 символів";
    }
    if(empty($_POST['title'])){
        $errors['title_empty'] = "Поле Заголовок не може бути пустим";
    }
    if(empty($_POST['short_description'])){
        $errors['short_description'] = "Поле Короткий опис не може бути пустим";
    }
    if(empty($_POST['content'])){
        $errors['content'] = "Поле Текст новини не може бути пустим";
    }

    if (count($errors) === 0) {
        $data = [
            "title" => $_POST['title'],
            "short_description" => $_POST['short_description'],
            "content" => $_POST['content'],
            "created_at" => date("Y-m-d H:i:s")
        ];
        $newsId = $db->insert ('news', $data);
    }
}

?>
<!-- Page Header-->
<header class="masthead" style="background-image: url('/assets/img/contact-bg.jpg')">
    <div class="container position-relative px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-7">
                <div class="page-heading">
                    <h1>Новини</h1>
                    <span class="subheading">Додавання нової новини</span>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- Main Content-->
<main class="mb-4">
    <div class="container px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-7">
                <?php if(count($errors) > 0){ ?>
                    <div class="fw-bolder"><span class="snowflake">Виправте помилки:</span></div>
                    <?php foreach($errors as $oneError) { ?>
                        <p><span class="snowflake"><?php echo $oneError ?></span></p>
                    <?php } ?>
                <?php } ?>
                
                <?php if(isset($newsId) and !empty($newsId)){ ?>
                    <!-- Submit success message-->
                    <div id="submitSuccessMessage">
                        <div class="text-center mb-3">
                            <div class="fw-bolder">Новина успішно додана</div>
                            Перейдіть за посиланням для перегляду новини
                            <br />
                            <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/news/<?php echo$newsId ?>">https://<?php echo $_SERVER['HTTP_HOST'] ?>/news/<?php echo$newsId ?></a>
                        </div>
                    </div>
                <?php } ?>
                        
                <div class="my-5">
                    <!-- * * * * * * * * * * * * * * *-->
                    <!-- * * SB Forms Contact Form * *-->
                    <!-- * * * * * * * * * * * * * * *-->
                    <!-- This form is pre-integrated with SB Forms.-->
                    <!-- To make this form functional, sign up at-->
                    <!-- https://startbootstrap.com/solution/contact-forms-->
                    <!-- to get an API token!-->
                    <form id="contactForm" data-sb-form-api-token="API_TOKEN" action="/create-news" method="post">
                        <div class="form-floating">
                            <input class="form-control" type="text" name="title" placeholder="Введіть заголовок" />
                            <label for="name">Заголовок<span class="snowflake">*</span></label>
                        </div>
    
                        <div class="form-floating">
                            <textarea class="form-control" id="message" name="short_description" placeholder="Введіть короткий опис" style="height: 12rem"></textarea>
                            <label for="message">Короткий опис<span class="snowflake">*</span></label>
                        </div>
                        
                        <div class="form-floating">
                            <textarea class="form-control" id="message" name="content" placeholder="Введіть текст новини" style="height: 12rem"></textarea>
                            <label for="message">Текст новини<span class="snowflake">*</span></label>
                        </div>
                        <br />
                        
                        
                        <!-- Submit Button-->
                        <button class="btn btn-primary text-uppercase" id="submitButton" type="submit">Send</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>

<?php
require_once __DIR__ . '/inc/footer_admin.php';

